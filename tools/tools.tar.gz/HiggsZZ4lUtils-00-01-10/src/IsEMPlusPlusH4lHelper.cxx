/********************************************************************

    Name:     IsEMPlusPlusH4lHelper.cxx

*********************************************************************/
#include "HiggsZZ4lUtils/IsEMPlusPlusH4lHelper.h"
#include "HiggsZZ4lUtils/IsEMPlusPlusH4lDefs.h"
// ====================================================================
bool isEMPlusPlusH4lHelper::IsLoosePlusPlusH4l(const egamma* eg,
                                               bool debug,
                                               bool isTrigger){
  
    
    if (!eg) {
      std::cout << "Failed, no egamma object. " << std::endl;
      return false; 
    }
    const CaloCluster* cluster = eg->cluster();
    if(!cluster){
      if(debug)
	std::cout << "Failed, no cluster. " << std::endl;
      return false; 
    }  

    float eta = fabs(cluster->etaBE(2)); 
    if(eta > 2.47){
      if(debug)
	std::cout << "Failed, eta range. " << std::endl;
      return false;
    }

    float et = cluster->energy()/cosh(eta); 

    float e237   = eg->detailValue(egammaParameters::e237);
    float e277   = eg->detailValue(egammaParameters::e277);
    float Reta = e277 != 0 ? e237/e277 : 0.;
    float weta2c = eg->detailValue(egammaParameters::weta2);

    double ethad1 = eg->detailValue(egammaParameters::ethad1);
    double ethad = eg->detailValue(egammaParameters::ethad);
    double raphad1 = fabs(et) != 0. ? ethad1/et : 0.;
    double raphad  = fabs(et) != 0. ? ethad/et : 0.;
  
    // E of 2nd max between max and min in strips
    double emax2  = eg->detailValue(egammaParameters::e2tsts1);
    // E of 1st max in strips
    double emax   = eg->detailValue(egammaParameters::emaxs1);

    // fraction of energy reconstructed in the 1st sampling
    double f1     = eg->detailValue(egammaParameters::f1);
    
    // E of 1st max in strips
    double wtot   = eg->detailValue(egammaParameters::wtots1);
    
    // (Emax1-Emax2)/(Emax1+Emax2)
    double demaxs1 = (emax+emax2)==0. ? 0 : (emax-emax2)/(emax+emax2);
    
    // number of precision hits (Pixels+SCT)
    int nSi = 0;
    int nPi = 0;
    int nSiOutliers = 0; 
    int nPiOutliers = 0; 

    // retrieve associated track
    const Rec::TrackParticle* track  = eg->trackParticle();    

    if (track) {
     const Trk::TrackSummary* summary = track->trackSummary();

      if (summary) {
        nPi = summary->get(Trk::numberOfPixelHits);
        nSi = summary->get(Trk::numberOfPixelHits)+summary->get(Trk::numberOfSCTHits);
        nPiOutliers = summary->get(Trk::numberOfPixelOutliers);	
        nSiOutliers = summary->get(Trk::numberOfPixelOutliers)+summary->get(Trk::numberOfSCTOutliers);
        
        }
    } 
    else {
      std::cout << "Failed, no track particle: et= " << et << "eta= " << eta << std::endl;
    }


    // delta eta
    double deltaEta = fabs(eg->detailValue(egammaParameters::deltaEta1));

    bool result = isLoosePlusPlusH4l(eta,et,
                                     raphad,raphad1,Reta,weta2c,
                                     f1,wtot,demaxs1,deltaEta,nSi,nSiOutliers,
                                     nPi, nPiOutliers,
                                     debug,isTrigger);
				  
    if (debug)
    {
      std::cout << "rhad= "     << raphad  << "  " << raphad1 << std::endl;
      std::cout << "reta= "     << Reta  << std::endl;
      std::cout << "wstot= "    << wtot  << std::endl;
      std::cout << "weta2= "    << weta2c  << std::endl;
      std::cout << "eratio= "   << demaxs1  << std::endl;
      std::cout << "npix= "     << nPi + nPiOutliers  << std::endl;
      std::cout << "nsi= "      << nSi + nSiOutliers  << std::endl; 
      std::cout << "deltaEta= "      << deltaEta  << std::endl;
    }

    return result;
}


