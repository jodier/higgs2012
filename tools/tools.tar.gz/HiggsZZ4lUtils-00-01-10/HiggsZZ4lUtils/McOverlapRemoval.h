//////////////////////////////////////////////////////////////
// Small macro to remove overlaps                          /// 
// between H->4l related                                   ///
// MC samples                                              ///
//////////////////////////////////////////////////////////////
// Usage:                                                  ///
// mc_channel_number1 : sample to remove events from       /// 
//                     (current sample)                    ///          
// mc_channel_number2 : core sample                        ///
// MC_n               : number of entries in truth record  ///
// MC_pt,             : pointer to the relevant D3PD info  ///
// MC_eta,                                                 /// 
// MC_phi,                                                 ///
// MC_m,                                                   ///
// MC_status,                                              ///
// MC_pdgId                                                ///
//////////////////////////////////////////////////////////////
// K. Nikolopoulos (U. Birmingham)                         ///
// May 23, 2012                                            ///
//////////////////////////////////////////////////////////////
#include<iomanip>
using namespace std;

bool killEvent(UInt_t mc_channel_number1, UInt_t mc_channel_number2,
	       Int_t MC_n,
	       vector<float>* MC_pt,
	       vector<float>* MC_eta,
	       vector<float>* MC_phi,
	       vector<float>* MC_m,
	       vector<int>* MC_status,
	       vector<int>* MC_pdgId,
	       )
{
  switch(mc_channel_number2)
    {
    case 109346: 

      switch(mc_channel_number1)
	{
	case 109345:
	case 105200:
	  	  std::vector<TLorentzVector*> temp;
	  int icount=0;
	  for(int i = 0; i < MC_n; i++)
	    {
	      if(MC_pt->at(i)<5.e3)
		continue;
	      if(MC_status->at(i)!=1)
		continue;
	      if(TMath::Abs(MC_pdgId->at(i)) == 13 ||TMath::Abs(MC_pdgId->at(i)) == 11)
		{
		  temp.push_back(new TLorentzVector());
		  temp.at(icount)->SetPtEtaPhiM(MC_pt->at(i)/1000.0, MC_eta->at(i), MC_phi->at(i), MC_m->at(i)/1000.0);
		  icount++;
		}
	    }
	  bool filter = false;
	  if(icount>3)
	    {
	      for(int i=0;i<icount;i++)
		{
		  for(int j=0;j<icount;j++)
		    {
		      if(i==j)
			continue;
		      for(int k=0;k<icount;k++)
			{
			  if(i==k||j==k)
			    continue;
			  for(int l=0;l<icount;l++)
			    {
			      if(i==l||j==l||k==l)
				continue;
			      double mass1= (*temp.at(i)+ *temp.at(j)).M();
			      double mass2= (*temp.at(k)+ *temp.at(l)).M();
			      if(mass1>60. && mass2>12.)
				filter=true;
			    }
			}
		    }
		}
	    }
	  for(int i=0;i<icount;i++)
	    delete temp.at(i);
	  if(filter)
	    return true;
	  
	default:
	  cout<< "not known overlap"<<std::endl;
	  return false;
	}
    
    default:
      cout<< "not known overlap"<<std::endl;
      return false;
    }
}

