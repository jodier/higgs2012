#ifndef CROSSSECTION_H
#define CROSSSECTION_H


namespace CrossSections{

  enum LHCEnergy{
    SevenTeV = 1,
    EightTeV = 2
  };

}

#endif
