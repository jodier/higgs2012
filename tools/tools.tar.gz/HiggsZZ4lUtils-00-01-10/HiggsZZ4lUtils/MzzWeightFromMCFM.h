#ifndef MZZWEIGHTFROMMFCM_H
#define MZZWEIGHTFROMMFCM_H

double GetMzzWeightFromMCFM(double mZZ);

#endif
