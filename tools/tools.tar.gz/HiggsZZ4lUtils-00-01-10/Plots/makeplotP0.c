//////////////////
// plot p0
//
//
int makeplotP0(int type)
{
  std::vector<double> massOld,pvalueOld,pvalueeOld;
  fstream filestr0 ("pvalue_mu0-3round.txt", fstream::in);//4.8/fb final workspace for paper look only on last column (asymptotics for expected p0) [w/o interpolations]
  do
   {
     double mm,pv,pve;
     filestr0 >> mm>> pv>>pve;
     //std::cerr<<mm<<"\t"<< pv<<"\t"<<pve<<"\t"<<sqrt(ROOT::Math::chisquared_quantile_c(pve*2,1))<<"\n";
     massOld.push_back(mm);
     pvalueOld.push_back(pv);
     pvalueeOld.push_back(pve);
   }
  while(!filestr0.eof());
  filestr0.close();
  
  std::vector<double> mass,pvalue_o,pvalue_e,pvalue_pao, pvalue_pah;
  fstream filestr ("Pvalue_v2/NoZMassConstraint_pvalue.txt", fstream::in);
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     //if(mm>2800. && mm<=4000.)
       //continue;
     mass.push_back(mm/10.);
     pvalue_o.push_back(pvo);
     pvalue_e.push_back(pve);
     pvalue_pao.push_back(pvv);
     pvalue_pah.push_back(pvvv);
   }
  while(!filestr.eof());
  filestr.close();

  std::vector<double> mass_hugezz,pvalue_hugezz_o,pvalue_hugezz_e;
  fstream filestr ("Pvalue_v2/NoZMassConstraintHugeErrorZZ_pvalue.txt", fstream::in);//4.8/fb re-analysis
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     //if(mm>2800. && mm<=4000.)
       //continue;
     mass_hugezz.push_back(mm/10.);
     pvalue_hugezz_o.push_back(pvo);
     pvalue_hugezz_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();

  std::vector<double> mass_hugezjet,pvalue_hugezjet_o,pvalue_hugezjet_e;
  fstream filestr ("Pvalue_v2/NoZMassConstraintHugeErrorZjetZbbtt_pvalue.txt", fstream::in);//4.8/fb re-analysis
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     //if(mm>2800. && mm<=4000.)
       //continue;
       mass_hugezjet.push_back(mm/10.);
     pvalue_hugezjet_o.push_back(pvo);
     pvalue_hugezjet_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();

  std::vector<double> mass_hugebkg,pvalue_hugebkg_o,pvalue_hugebkg_e;
  fstream filestr ("Pvalue_v2/NoZMassConstraintHugeErrorBkg_pvalue.txt", fstream::in);//4.8/fb re-analysis
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     //if(mm>2800. && mm<=4000.)
       //continue;
       mass_hugebkg.push_back(mm/10.);
     pvalue_hugebkg_o.push_back(pvo);
     pvalue_hugebkg_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();

  std::vector<double> mass0,pvalue0_o,pvalue0_e;
  fstream filestr ("subchannels/NoZMassConstraint_4mu_pvalue.txt", fstream::in);
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     if(mm>2800. && mm<=4000.)
       continue;
     mass0.push_back(mm/10.);
     pvalue0_o.push_back(pvo);
     pvalue0_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();
  std::vector<double> mass1,pvalue1_o,pvalue1_e;
  fstream filestr ("subchannels/NoZMassConstraint_2mu2e_pvalue.txt", fstream::in);
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     if(mm>2800. && mm<=4000.)
       continue;
     mass1.push_back(mm/10.);
     pvalue1_o.push_back(pvo);
     pvalue1_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();
  std::vector<double> mass2,pvalue2_o,pvalue2_e;
  fstream filestr ("subchannels/NoZMassConstraint_4e_pvalue.txt", fstream::in);
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     if(mm>2800. && mm<=4000.)
       continue;
     mass2.push_back(mm/10.);
     pvalue2_o.push_back(pvo);
     pvalue2_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();
  std::vector<double> mass3,pvalue3_o,pvalue3_e;
  fstream filestr ("subchannels/NoZMassConstraint_2e2mu_pvalue.txt", fstream::in);
  do
   {
     double mm,pvo,pve,pvv,pvvv;
     filestr >> mm>> pvo>>pve>>pvv>>pvvv;
     if(mm>2800. && mm<=4000.)
       continue;
     mass3.push_back(mm/10.);
     pvalue3_o.push_back(pvo);
     pvalue3_e.push_back(pve);
   }
  while(!filestr.eof());
  filestr.close();

  TGraph*grOldo=new TGraph(massOld.size(),&massOld[0],&pvalueOld[0]);
  grOldo->SetLineWidth(2);
  grOldo->SetLineColor(4);
  TGraph*grOlde=new TGraph(massOld.size(),&massOld[0],&pvalueeOld[0]);
  grOlde->SetLineWidth(2);
  grOlde->SetLineStyle(2);
  grOlde->SetLineColor(4);

  TGraph*gro=new TGraph(mass.size(),&mass[0],&pvalue_o[0]);
  gro->SetLineWidth(2);
  gro->SetLineColor(2);
  TGraph*gre=new TGraph(mass.size(),&mass[0],&pvalue_e[0]);
  gre->SetLineWidth(2);
  gre->SetLineColor(2);
  gre->SetLineStyle(2);
  TGraph*grpao=new TGraph(mass.size(),&mass[0],&pvalue_pao[0]);
  grpao->SetLineWidth(2);
  grpao->SetLineStyle(2);
  TGraph*grpah=new TGraph(mass.size(),&mass[0],&pvalue_pah[0]);
  grpah->SetLineWidth(2);
  grpah->SetLineStyle(2);

  TGraph*grhugezzo=new TGraph(mass_hugezz.size(),&mass_hugezz[0],&pvalue_hugezz_o[0]);
  grhugezzo->SetLineWidth(2);
  TGraph*grhugezze=new TGraph(mass_hugezz.size(),&mass_hugezz[0],&pvalue_hugezz_e[0]);
  grhugezze->SetLineWidth(2);
  grhugezze->SetLineStyle(2);

  TGraph*grhugezjeto=new TGraph(mass_hugezjet.size(),&mass_hugezjet[0],&pvalue_hugezjet_o[0]);
  grhugezjeto->SetLineWidth(2);
  grhugezjeto->SetLineColor(4);
  TGraph*grhugezjete=new TGraph(mass_hugezjet.size(),&mass_hugezjet[0],&pvalue_hugezjet_e[0]);
  grhugezjete->SetLineWidth(2);
  grhugezjete->SetLineColor(4);
  grhugezjete->SetLineStyle(2);

  TGraph*grhugebkgo=new TGraph(mass_hugebkg.size(),&mass_hugebkg[0],&pvalue_hugebkg_o[0]);
  grhugebkgo->SetLineWidth(2);
  grhugebkgo->SetLineColor(4);
  TGraph*grhugebkge=new TGraph(mass_hugebkg.size(),&mass_hugebkg[0],&pvalue_hugebkg_e[0]);
  grhugebkge->SetLineWidth(2);
  grhugebkge->SetLineColor(4);
  grhugebkge->SetLineStyle(2);

  TGraph*grsubo[4];
  grsubo[0]=new TGraph(mass0.size(),&mass0[0],&pvalue0_o[0]);
  grsubo[1]=new TGraph(mass1.size(),&mass1[0],&pvalue1_o[0]);
  grsubo[2]=new TGraph(mass2.size(),&mass2[0],&pvalue2_o[0]);
  grsubo[3]=new TGraph(mass3.size(),&mass3[0],&pvalue3_o[0]);
  TGraph*grsube[4];
  grsube[0]=new TGraph(mass0.size(),&mass0[0],&pvalue0_e[0]);
  grsube[1]=new TGraph(mass1.size(),&mass1[0],&pvalue1_e[0]);
  grsube[2]=new TGraph(mass2.size(),&mass2[0],&pvalue2_e[0]);
  grsube[3]=new TGraph(mass3.size(),&mass3[0],&pvalue3_e[0]);
  for(int i=0;i<4;i++)
    {
      grsubo[i]->SetLineWidth(2);
      grsube[i]->SetLineWidth(2);
      grsube[i]->SetLineStyle(2);
      grsubo[i]->SetLineColor(6+i);
      grsube[i]->SetLineColor(6+i);
    }
  ////// plotting 
  TH2F*dummy=new TH2F("dummy",";m_{H} [GeV];Local p_{0}",520,90.,610.,19000,1.e-5,1.9);
  dummy->GetYaxis()->SetRangeUser(0.999e-5,0.999999999);
  dummy->GetYaxis()->SetTitleOffset(1.23);
  dummy->GetXaxis()->SetRangeUser(110.,599.9);
  dummy->GetXaxis()->SetNdivisions(505);
  dummy->GetXaxis()->SetLabelOffset(0.015);
  dummy->GetXaxis()->SetTitleOffset(1.1);
  double twosigma=(1.-0.954499736104)/2.;
  double threesigma=(1.-0.997300203937)/2.;
	
  vector<double> _2sigma, _3sigma;
  for(int i = 0 ; i < (int)mass_hugebkg.size(); i++){
    _2sigma.push_back(twosigma);
    _3sigma.push_back(threesigma);
  }
  TGraph* gr2sigma =new TGraph(mass_hugebkg.size(),&mass_hugebkg[0],&_2sigma[0]);
  TGraph* gr3sigma =new TGraph(mass_hugebkg.size(),&mass_hugebkg[0],&_3sigma[0]);

  TLine*line2=new TLine(110., twosigma, 600., twosigma);
  line2->SetLineWidth(2);
  line2->SetLineStyle(2);
  line2->SetLineColor(kRed+1);
  TLine*line3=new TLine(110., threesigma, 600., threesigma);
  line3->SetLineWidth(2);
  line3->SetLineStyle(2);
  line3->SetLineColor(kRed+1);
  ////////
  TCanvas*c1=new TCanvas("c1","",600,600);
  c1->SetMargin(0.13,0.05,0.12,0.05);
  c1->SetLogy();
  dummy->Draw();
  //line2->Draw();
  //line3->Draw();
  gr2sigma ->Draw("L");
  gr3sigma ->Draw("L");
  gr2sigma->SetLineWidth(2);
  gr2sigma->SetLineStyle(2);
  gr2sigma->SetLineColor(kRed+1);
  gr3sigma->SetLineWidth(2);
  gr3sigma->SetLineStyle(2);
  gr3sigma->SetLineColor(kRed+1);
  
  //gre->SetMarkerStyle(20);//temporary to indicate mass points used
  gre->SetMarkerStyle(20);//temporary to indicate mass points used
  if(type==0)
    {
      gro->Draw("L");
      gre->Draw("L");
  
      grOldo->Draw("L");
      grOlde->Draw("L");
    }
  else if(type==1) //norm vs huge ZZ
    {

      gro->Draw("L");
      gre->Draw("L");
      grhugezzo->Draw("L");
      grhugezze->Draw("L");
    }
  else if(type==2) //norm vs huge zjet,zbb,tt
    {
      gro->Draw("L");
      gre->Draw("L");
      grhugezjeto->Draw("L");
      grhugezjete->Draw("L");
    }
  else if(type==3) //norm vs huge bkg
    {
      gro->Draw("L");
      gre->Draw("L");
      grhugebkgo->Draw("L");
      grhugebkge->Draw("L");
    }
  else if(type==4) 
    {
      gro->SetLineColor(1);
      gre->SetLineColor(1);
      gro->Draw("L");
      gre->Draw("L");
      for(int i=0;i<4;i++)
	{
	  grsubo[i]->Draw("L");
	  grsube[i]->Draw("L");
	}
    }else if(type == 5){
      gro->SetLineColor(1); 
      gre->SetLineColor(2);
      grpao ->SetLineColor(8);
      grpah ->SetLineColor(4);
      gro->Draw("L");
      gre->Draw("L");
      grpao->Draw("L");
      grpah->Draw("L");
    }
  TLegend*leg0=new TLegend(0.16,0.15,0.53,0.35);////0.25);
  leg0->SetFillColor(0);
  leg0->SetLineColor(0);
  leg0->SetTextFont(42);
  leg0->SetTextSize(0.05);
  if(type==0)
    {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected","l");
      leg0->AddEntry(grOldo,"Observed Pub","l");
      leg0->AddEntry(grOlde,"Expected Pub","l");
    }
  else if(type==1)
    {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected","l");
      leg0->AddEntry(grhugezzo,"Observed free ZZ","l");
      leg0->AddEntry(grhugezze,"Expected free ZZ","l");
    }
  else if(type==2)
    {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected","l");
      leg0->AddEntry(grhugezjeto,"Observed free non-ZZ bkg","l");
      leg0->AddEntry(grhugezjete,"Expected free non-ZZ bkg","l");
    }
  else if(type==3)
    {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected","l");
      leg0->AddEntry(grhugebkgo,"Observed free bkg","l");
      leg0->AddEntry(grhugebkge,"Expected free bkg","l");
    }
  else if(type==4)
    {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected","l");
      leg0->AddEntry(grsubo[0],"4#mu","l");
      leg0->AddEntry(grsubo[1],"2#mu 2e","l");
      leg0->AddEntry(grsubo[2],"4e","l");
      leg0->AddEntry(grsubo[3],"2e2#mu","l");
    }
  else if (type ==5)
  {
      leg0->AddEntry(gro,"Observed","l");
      leg0->AddEntry(gre,"Expected PA 0","l");
      leg0->AddEntry(grpao,"Expected PA 1","l");
      leg0->AddEntry(grpah,"Expected PA #hat{#mu}","l");
  }
  leg0->Draw();


  TLatex l;
  l.SetNDC();
  l.SetTextFont(42);
  l.SetTextSize(0.05);
  l.SetTextColor(1);
  l.SetTextAlign(12);
  TLatex* l1 = l.DrawLatex(0.52,0.40,"#bf{#it{ATLAS}} Internal");//:Preliminary");
  //TLatex* l1 = l.DrawLatex(0.66,0.35,"#bf{#it{ATLAS}}");//
  TLatex* l2 = l.DrawLatex(0.63,0.30,"H#rightarrow ZZ^{(*)}#rightarrow 4l");
  TLatex* l3 = l.DrawLatex(0.63,0.23,"#lower[-0.15]{#scale[0.6]{#int}}Ldt = 4.8 fb^{-1}");
  TLatex* l4 = l.DrawLatex(0.63,0.18,"#sqrt{s}=7 TeV");
  l.SetNDC(0);
  l.SetTextSize(0.04);
  TLatex* l5 = l.DrawLatex(605.,twosigma,"2#sigma");
  TLatex* l6 = l.DrawLatex(605.,threesigma,"3#sigma");

  TLatex* tck=new TLatex();
  tck->SetNDC();
  tck->SetTextFont(42);
  tck->SetTextSize(0.05);
  TLatex* tck0=tck->DrawLatex(0.095,0.065,"110");
  c1->Update();
  TString name("p0plot_");
  name+=type;
  name+=".eps";
  c1->Print(name);
  delete tck0;

  dummy->GetXaxis()->SetNdivisions(510);
  line2->SetX1(110.);
  line2->SetX2(199.99);
  line3->SetX1(110.);
  line3->SetX2(199.99);
  l1->SetX(0.22);
  l1->SetNDC();
  l5->SetX(201.);
  l6->SetX(201.);
  //dummy->GetXaxis()->SetRangeUser(110.,199.99);
  dummy->GetXaxis()->SetRangeUser(110.,169.99);
  //dummy->GetYaxis()->SetRangeUser(1.e-3,0.99999);
  //delete line3;
  //delete l6;
  c1->Update();
  TString name2("p0plotZoom_");
  name2+=type;
  name2+=".eps";
  c1->Print(name2);
  return 0;
}
