#ifdef __CINT__
#include "MuonIsolationCorrection/CorrectCaloIso.h"
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ nestedclass;
#pragma link C++ class CorrectCaloIso;
#endif
