// C/C++  
#include <iostream>
#include <math.h>

// Local
#include "MuonIsolationCorrection/CorrectCaloIso.h"

//////////////////////////////////////////////////
// To get the corrected relative Isolation call:
// CorrectEtConeRel(pt, isoConeRel, nvtx, eta, opts)
//    -- author: Doug Schaefer <schae@cern.ch>
//////////////////////////////////////////////////

using namespace std;

//-----------------------------------------------------------------------------
CorrectCaloIso::CorrectCaloIso() : fDebug(false), fOpts("cone30Comb")
{
  //
  // Configuring the eta dependent Isolation corrections
  //
  ConfigEtCone30Comb();
}

//-----------------------------------------------------------------------------
CorrectCaloIso::~CorrectCaloIso()
{
}

//-----------------------------------------------------------------------------
void CorrectCaloIso::ConfigEtCone20Comb()
{ //                   
  // Eta dependent isolation from Doug's Ztag and probe  
  //   -- 11/7/2011                                      
  //   -- units are MeV
  //
  fSlope[0] =32.2;  fConstant[0] =207.4;  //fEta[0] =0.10; 
  fSlope[1] =32.2;  fConstant[1] =207.4;  //fEta[1] =0.20; 
  fSlope[2] =32.2;  fConstant[2] =207.4;  //fEta[2] =0.30; 
  fSlope[3] =32.2;  fConstant[3] =207.4;  //fEta[3] =0.40; 
  fSlope[4] =32.2;  fConstant[4] =207.4;  //fEta[4] =0.50; 
  fSlope[5] =32.2;  fConstant[5] =207.4;  //fEta[5] =0.60; 
  fSlope[6] =32.2;  fConstant[6] =207.4;  //fEta[6] =0.70; 
  fSlope[7] =32.2;  fConstant[7] =207.4;  //fEta[7] =0.80; 
  fSlope[8] =32.2;  fConstant[8] =207.4;  //fEta[8] =0.90; 
  fSlope[9] =32.2;  fConstant[9] =207.4;  //fEta[9] =1.00; 
  fSlope[10]=32.2;  fConstant[10]=207.4;  //fEta[10]=1.10; 
  fSlope[11]=32.2;  fConstant[11]=207.4;  //fEta[11]=1.20; 
  fSlope[12]=32.2;  fConstant[12]=207.4;  //fEta[12]=1.30; 
  fSlope[13]=32.2;  fConstant[13]=207.4;  //fEta[13]=1.40; 
  fSlope[14]=32.2;  fConstant[14]=207.4;  //fEta[14]=1.50; 
  fSlope[15]=32.2;  fConstant[15]=207.4;  //fEta[15]=1.60; 
  fSlope[16]=32.2;  fConstant[16]=207.4;  //fEta[16]=1.70; 
  fSlope[17]=32.2;  fConstant[17]=207.4;  //fEta[17]=1.80; 
  fSlope[18]=32.2;  fConstant[18]=207.4;  //fEta[18]=1.90; 
  fSlope[19]=32.2;  fConstant[19]=207.4;  //fEta[19]=2.00; 
  fSlope[20]=32.2;  fConstant[20]=207.4;  //fEta[20]=2.10; 
  fSlope[21]=32.2;  fConstant[21]=207.4;  //fEta[21]=2.20; 
  fSlope[22]=32.2;  fConstant[22]=207.4;  //fEta[22]=2.30; 
  fSlope[23]=32.2;  fConstant[23]=207.4;  //fEta[23]=2.40; 
  fSlope[24]=32.2;  fConstant[24]=207.4;  //fEta[24]=2.50; 
  fSlope[25]=32.2;  fConstant[25]=207.4;  //fEta[25]=2.60; 
  fSlope[26]=32.2;  fConstant[26]=207.4;  //fEta[26]=2.70; 

}

//-----------------------------------------------------------------------------
void CorrectCaloIso::ConfigEtCone30Comb()
{ //                   
  // Eta dependent isolation from Peter's Ztag and probe  
  //   -- 11/7/2011                                      
  //   -- units are MeV  
  //
  fSlope[0] =81.4380;  fConstant[0] =256.798;  //fEta[0] =0.10; 
  fSlope[1] =88.7883;  fConstant[1] =222.295;  //fEta[1] =0.20; 
  fSlope[2] =90.4055;  fConstant[2] =246.810;  //fEta[2] =0.30; 
  fSlope[3] =88.5415;  fConstant[3] =256.253;  //fEta[3] =0.40; 
  fSlope[4] =89.8105;  fConstant[4] =253.627;  //fEta[4] =0.50; 
  fSlope[5] =87.2666;  fConstant[5] =269.239;  //fEta[5] =0.60; 
  fSlope[6] =89.8660;  fConstant[6] =231.288;  //fEta[6] =0.70; 
  fSlope[7] =88.4182;  fConstant[7] =219.546;  //fEta[7] =0.80; 
  fSlope[8] =83.7103;  fConstant[8] =238.926;  //fEta[8] =0.90; 
  fSlope[9] =88.3318;  fConstant[9] =193.716;  //fEta[9] =1.00; 
  fSlope[10]=85.1312;  fConstant[10]=207.372;  //fEta[10]=1.10; 
  fSlope[11]=86.0413;  fConstant[11]=306.257;  //fEta[11]=1.20; 
  fSlope[12]=81.6753;  fConstant[12]=250.002;  //fEta[12]=1.30; 
  fSlope[13]=78.6961;  fConstant[13]=377.195;  //fEta[13]=1.40; 
  fSlope[14]=66.8804;  fConstant[14]=259.919;  //fEta[14]=1.50; 
  fSlope[15]=71.9913;  fConstant[15]=187.506;  //fEta[15]=1.60; 
  fSlope[16]=73.2569;  fConstant[16]=275.101;  //fEta[16]=1.70; 
  fSlope[17]=78.2649;  fConstant[17]=165.755;  //fEta[17]=1.80; 
  fSlope[18]=77.9631;  fConstant[18]=199.264;  //fEta[18]=1.90; 
  fSlope[19]=79.0986;  fConstant[19]=198.490;  //fEta[19]=2.00; 
  fSlope[20]=85.7765;  fConstant[20]=153.297;  //fEta[20]=2.10; 
  fSlope[21]=77.4238;  fConstant[21]=177.392;  //fEta[21]=2.20; 
  fSlope[22]=75.9160;  fConstant[22]=120.396;  //fEta[22]=2.30; 
  fSlope[23]=70.5277;  fConstant[23]=123.942;  //fEta[23]=2.40; 
  fSlope[24]=70.5277;  fConstant[24]=123.942;  //fEta[24]=2.50; 
  fSlope[25]=70.5277;  fConstant[25]=123.942;  //fEta[25]=2.60; 
  fSlope[26]=70.5277;  fConstant[26]=123.942;  //fEta[26]=2.70; 
}

//-----------------------------------------------------------------------------
void CorrectCaloIso::ConfigEtCone40Comb()
{ //                   
  // Eta dependent isolation from Doug's Ztag and probe  
  //   -- 11/7/2011                                      
  //   -- units are MeV  
  //
  fSlope[0] =149.5;  fConstant[0] =365.6;  //fEta[0] =0.10; 
  fSlope[1] =149.5;  fConstant[1] =365.6;  //fEta[1] =0.20; 
  fSlope[2] =149.5;  fConstant[2] =365.6;  //fEta[2] =0.30; 
  fSlope[3] =149.5;  fConstant[3] =365.6;  //fEta[3] =0.40; 
  fSlope[4] =149.5;  fConstant[4] =365.6;  //fEta[4] =0.50; 
  fSlope[5] =149.5;  fConstant[5] =365.6;  //fEta[5] =0.60; 
  fSlope[6] =149.5;  fConstant[6] =365.6;  //fEta[6] =0.70; 
  fSlope[7] =149.5;  fConstant[7] =365.6;  //fEta[7] =0.80; 
  fSlope[8] =149.5;  fConstant[8] =365.6;  //fEta[8] =0.90; 
  fSlope[9] =149.5;  fConstant[9] =365.6;  //fEta[9] =1.00; 
  fSlope[10]=149.5;  fConstant[10]=365.6;  //fEta[10]=1.10; 
  fSlope[11]=149.5;  fConstant[11]=365.6;  //fEta[11]=1.20; 
  fSlope[12]=149.5;  fConstant[12]=365.6;  //fEta[12]=1.30; 
  fSlope[13]=149.5;  fConstant[13]=365.6;  //fEta[13]=1.40; 
  fSlope[14]=149.5;  fConstant[14]=365.6;  //fEta[14]=1.50; 
  fSlope[15]=149.5;  fConstant[15]=365.6;  //fEta[15]=1.60; 
  fSlope[16]=149.5;  fConstant[16]=365.6;  //fEta[16]=1.70; 
  fSlope[17]=149.5;  fConstant[17]=365.6;  //fEta[17]=1.80; 
  fSlope[18]=149.5;  fConstant[18]=365.6;  //fEta[18]=1.90; 
  fSlope[19]=149.5;  fConstant[19]=365.6;  //fEta[19]=2.00; 
  fSlope[20]=149.5;  fConstant[20]=365.6;  //fEta[20]=2.10; 
  fSlope[21]=149.5;  fConstant[21]=365.6;  //fEta[21]=2.20; 
  fSlope[22]=149.5;  fConstant[22]=365.6;  //fEta[22]=2.30; 
  fSlope[23]=149.5;  fConstant[23]=365.6;  //fEta[23]=2.40; 
  fSlope[24]=149.5;  fConstant[24]=365.6;  //fEta[24]=2.50; 
  fSlope[25]=149.5;  fConstant[25]=365.6;  //fEta[25]=2.60; 
  fSlope[26]=149.5;  fConstant[26]=365.6;  //fEta[26]=2.70; 
}

//-----------------------------------------------------------------------------    
void CorrectCaloIso::Config(const std::string opts) 
{
  //
  // Setting the Isolation Correction values
  //
  if(fOpts==opts) return;

  if     (opts=="cone30Comb") ConfigEtCone30Comb();
  else if(opts=="cone20Comb") ConfigEtCone20Comb();
  else if(opts=="cone40Comb") ConfigEtCone40Comb();
}

//-----------------------------------------------------------------------------    
unsigned CorrectCaloIso::GetEtaBin(const float &eta) const
{
  //                           
  // Find Eta bin
  //
  unsigned bin = static_cast<unsigned>(fabs(eta)/0.10);

  if(bin<27)  return bin;
  else{
    if(fDebug) std::cout << "ERROR bin is bigger than known isolation corrections!" << std::endl;
    return 26;
  }
}

//-----------------------------------------------------------------------------
float CorrectCaloIso::CorrectEtCone(const float &isoCone, const float &nvtx, const float &eta, const std::string opts)
{
  // 
  // Calculate corrected isolation variable 
  //    -- isoCone      is the EtCone
  //    -- nVtx         is number of primary vertices as calculated in the HSG3 recommendation
  //    -- eta          is the combined muon eta
  //         e.g. etconecor = (etcone - correction)
  //
  return isoCone - GetCorrectionEtCone(nvtx,eta,opts);
}

//-----------------------------------------------------------------------------
float CorrectCaloIso::CorrectEtConeRel(const float &pt, const float &isoConeRel, const float &nvtx, const float &eta, const std::string opts)
{
  // 
  // Calculate corrected relative isolation   
  //    -- pt           is in MeV and is the combined muon pt                 
  //    -- isoConeRel   is the EtCone/pt
  //    -- nVtx         is number of primary vertices as calculated in the HSG3 recommendation
  //    -- eta          is the combined muon eta
  //
  if(pt==0.0) return isoConeRel;
  float isoCone = isoConeRel*pt;

  //
  // Calculate the cone corrections  
  //   -- (etcone - correction)/pt
  //
  float newIsoCone = (isoCone - GetCorrectionEtCone(nvtx,eta,opts))/pt; 

  if(fDebug){
    std::cout << "Uncorrected Relative Isolation Cone :  " << isoConeRel
	      << " Pileup Corrected Relative Isolation:  " << newIsoCone 
	      << std::endl;
  }

  return newIsoCone;
}

//-----------------------------------------------------------------------------
float CorrectCaloIso::GetCorrectionEtCone(const unsigned &nvtx,const float &eta, const std::string opts)
{
  // Sets the isolation correction values
  Config(opts);
  
  const unsigned bin     = GetEtaBin(eta);
  const float slope      = fSlope   [bin];
  const float constant   = fConstant[bin];

  return CaloCor(nvtx, slope, constant);
}

//-----------------------------------------------------------------------------
float CorrectCaloIso::CaloCor(const unsigned &nvtx, const float &slope, const float &constant)
{
  //
  // Returns the correction to the calorimeter isolation
  //   -- this is the amount to subtract from the corrected cone
  //
  return float(nvtx)*slope + constant;
}
