// Dear emacs, this is -*- c++ -*-
// $Id: LeptonTriggerSF.h 506594 2012-06-20 18:17:45Z marx $
#ifndef TRIGMUONEFFICIENCY_LEPTONTRIGGERSF_H
#define TRIGMUONEFFICIENCY_LEPTONTRIGGERSF_H

// STL include(s):
#include <vector>
#include <map>

// ROOT include(s):
#include "TString.h"
#include "TLorentzVector.h"
#include "TH2.h"

// Forward declaration(s):
class egammaSFclass;
class TH2fileName;

namespace TrigMuonEff {
  struct Configuration {
    bool isData;
    std::string trigger;
    std::string period;
    std::string binning;

    Configuration(const bool isData_=true, const std::string& trigger_="", const std::string& period_="", const std::string& binning_="") :
      isData(isData_), trigger(trigger_),  period(period_), binning(binning_) {}
  };

   /// Helper enumeration defining the data periods understood by the tool
   enum SFDataPeriod {
      perUnDefined      = -1,
      per2011B_I        = 0, 
      per2011J_MwoL3_L4 = 1, 
      per2011L3_L4      = 2,

      //for HSG3 specific use
      per2011J   = 3,
      per2011K   = 4,
      per2011J_K = 5,
      per2011J_M = 6,
      per2011L_M = 7,

      // 2012
      per2012A = 8,
      per2012B = 9
   };
}

/// Helper enumeration defining the muon quality types
enum muon_quality {
   loose    = 0,
   combined = 1
};

/// Helper enumeration defining the electron quality types
enum electron_quality {
   loosepp  = 0,
   mediumpp = 1,
   tightpp  = 2,
   ML  = 3
};

/**
 *  @short Class providing trigger scale factors for analyses using electrons and muons
 *
 *         This tool can be used to get the scale factors and their uncertainties in
 *         events with multiple electrons/muons.
 *
 * @author Marilyn Marx <marx@cern.ch>
 * @author Junjie Zhu   <junjie@umich.edu>
 *
 * $Revision: 506594 $
 * $Date: 2012-06-20 20:17:45 +0200 (Wed, 20 Jun 2012) $
 */
class LeptonTriggerSF {

public:
   /// Constructor, taking a possible pass to directory which contains the ROOT file
   LeptonTriggerSF( const TString& directory = "" );
   /// Constructor, taking a possible pass to directory which contains the ROOT file and the name of the ROOT file
   LeptonTriggerSF( const int year, const TString& directory = "", const TString& fileName = "" );
   /// Destructor
   ~LeptonTriggerSF();

   /// Function getting the scale factor for leptons of uniform quality
   std::pair< Double_t, Double_t >
   GetTriggerSF( Int_t runnumber, Bool_t useGeV, const std::vector< TLorentzVector >& muons, muon_quality q,
                 const std::vector< TLorentzVector >& electrons, electron_quality p, Int_t var = 0,
                 TrigMuonEff::Configuration* configuration = 0 ) const;
   /// Function getting the scale factor for leptons of varying quality
   std::pair< Double_t, Double_t >
   GetTriggerSF( Int_t runnumber, Bool_t useGeV,
                 const std::vector< TLorentzVector >& muons, const std::vector< muon_quality >& vecq,
                 const std::vector< TLorentzVector >& electrons, const std::vector< electron_quality >& vecp,
                 Int_t var = 0,
                 TrigMuonEff::Configuration* configuration = 0 ) const;

   /// Function returning the trigger efficiency for a single muon
   std::pair< Double_t, Double_t >
   MuEff( const TrigMuonEff::Configuration& config, const TLorentzVector& muon,
          muon_quality mu_quality ) const;
   /// Function returning the trigger efficiency for a single muon
   std::pair< Double_t, Double_t >
   MuEff( TrigMuonEff::SFDataPeriod period, Bool_t isData, const TLorentzVector& muon,
          muon_quality mu_quality ) const;
   /// Function returning the trigger efficiency for a single electron, on Monte Carlo
   std::pair< Double_t, Double_t >
   ElEff_MC( const TLorentzVector& electron, Int_t set_mc, Bool_t useGeV = kFALSE, int fYear = 2011, Int_t runnumber = 200804) const;
   /// Function returning the trigger efficiency for a single electron, on data
   std::pair< Double_t, Double_t >
   ElEff_Data( const TLorentzVector& electron, Int_t set_mc, Int_t set_data,
               Bool_t useGeV = kFALSE, int fYear = 2011, Int_t runnumber = 200804) const;

private:
   /// Function initializing the tool on construction
   void Initialize( const TString& directory, const TString& fileName = "muon_trigger_sf.root" );

   /// Translate the muon quality enumeration into a value used internally by the tool
   static TString GetMuQuality( muon_quality mu_q );
   /// Translate the electron quality enumeration into a value used internally by the tool
   static Int_t GetElQuality( Int_t runnumber, electron_quality el_quality, Bool_t isSF );
   /// Get the minimum offline electron and muon pT thresholds for a given run
   static std::pair< Double_t, Double_t >
   GetThresholds( Bool_t useGeV, Int_t runnumber );
   /// Translate a run number to a data period
   static TrigMuonEff::SFDataPeriod GetDataPeriod( Int_t runNumber );
   /// Translate a phi value into the ATLAS [-pi,pi] frame
   static Double_t CheckPhiRange( Double_t phi );
   /// Function to calculate the uncertainty on the SF
   static Double_t GetSFError( Double_t a, Double_t b, Double_t c, Double_t d);

   int fYear;
   std::map< TString, TH2* > fEfficiencyMap; ///< The main efficiency storage location

   Double_t fPhiBoundaryBarrel; ///< Muon phi boundary in the barrel region
   Double_t fPhiBoundaryEndcap; ///< Muon phi boundary in the endcap region

   mutable egammaSFclass* fEgammaSF; ///< Helper class providing the electron scale factors

}; // class LeptonTriggerSF

#endif // TRIGMUONEFFICIENCY_LEPTONTRIGGERSF_H
