#ifndef PROBEQUALITYCUTS_H
#define PROBEQUALITYCUTS_H
//-------------------------------------------------------------------------------------------------------
bool passProbeQualityRHad(double eta, double eT,double rHad, double rHad1);
//----------------------------------------------------------------------------------------
#endif
